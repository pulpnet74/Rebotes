<style type="text/css">

	/* Ribbons off */
	
	#header, #footer, #wrapper #leftcol h3.moduleh3, #wrapper #rightcol h3.moduleh3 {
		margin:0;
	}
	#header {
		padding:0;
}
	.heckl, .heckr, .feckl, .feckr, .h3eckl, .h3eckr {  
		display:none;
	}

</style>