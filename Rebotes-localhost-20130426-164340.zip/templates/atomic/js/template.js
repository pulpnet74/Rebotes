/* Javscript Document  */
/*         function jurisprudence()
        {
            var w = window.open ('index.php', 'babopop', config='height=370, width=340, toolbar=no, menubar=no, scrollbars=yes, resizable=yes, location=no, directories=no, status=no');
            w.focus();
        } */
